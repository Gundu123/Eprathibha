import React, { useEffect, useState } from "react";
import axios from "axios";
import { useParams } from "react-router-dom";

const Question= ({ serverKey, id, tokenu }) => {
  const [questions, setQuestions] = useState([]);
  const { examId } = useParams();
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
  const [error, setError] = useState(null);

  useEffect(() => {
    const fetchData = async () => {
      try {
        const response = await axios.get(
          'http://test.e-prathibha.com/apis/start_exam?examId=24',
          {
            headers: {
              id,
              server_key: serverKey,
              tokenu,
            },
          }
        );
        console.log("response data:", response.data.data.exam);
        setQuestions(response.data.data.exam);
      } catch (error) {
        console.log(error);
        setError(error);
      }
    };
    fetchData();
  }, [examId, id, tokenu, serverKey]);

  const handleNextQuestion = () => {
    setCurrentQuestionIndex((prevIndex) => prevIndex + 1);
  };

  const currentQuestion = questions[currentQuestionIndex];

  if (!Array.isArray(questions) || questions.length === 0) {
    return <div>No questions available</div>;
  }

  return (
    <div>
      <div key={currentQuestionIndex}>
        <p>{currentQuestion.Question.question.above}</p>
        <p>
          <input type="radio" name="option" value="option1" />
          {currentQuestion.Question.option1}
        </p>
        <p>
          <input type="radio" name="option" value="option2" />
          {currentQuestion.Question.option2}
        </p>
        <p>
          <input type="radio" name="option" value="option3" />
          {currentQuestion.Question.option3}
        </p>
        <p>
          <input type="radio" name="option" value="option4" />
          {currentQuestion.Question.option4}
        </p>
      </div>
      <button onClick={handleNextQuestion}>Mark for review</button>
      <button onClick={handleNextQuestion}>Save&Next</button>

    </div>
  );
};

export default Question;
// import React, { useEffect, useState } from "react";
// import axios from "axios";
// import { useParams } from "react-router-dom";

// const Question = ({ serverKey, id, tokenu }) => {
//   const [questions, setQuestions] = useState([]);
//   const { examId } = useParams();
//   const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
//   const [error, setError] = useState(null);

//   useEffect(() => {
//     const fetchData = async () => {
//       try {
//         const response = await axios.get(
//           'http://test.e-prathibha.com/apis/start_exam?examId=24',
//           {
//             headers: {
//               id,
//               server_key: serverKey,
//               tokenu,
//             },
//           }
//         );
//         console.log("response data:", response.data.data.exam);
//         setQuestions(response.data.data.exam);
//       } catch (error) {
//         console.log(error);
//         setError(error);
//       }
//     };
//     fetchData();
//   }, [examId, id, tokenu, serverKey]);

//   const handleQuestionClick = (index) => {
//     setCurrentQuestionIndex(index);
//   };

//   const handleNextQuestion = () => {
//     setCurrentQuestionIndex((prevIndex) => prevIndex + 1);
//   };

//   const currentQuestion = questions[currentQuestionIndex];

//   if (!Array.isArray(questions) || questions.length === 0) {
//     return <div>No questions available</div>;
//   }

//   return (
//     <div className="question-container">
//       <div className="question-palette">
//         {questions.map((question, index) => (
//           <div
//             key={index}
//             className={`question-item ${index === currentQuestionIndex ? 'active' : ''}`}
//             onClick={() => handleQuestionClick(index)}
//           >
//             {index + 1}
//           </div>
//         ))}
//       </div>

//       <div className="question-content">
//         <div className="current-question">
//           <p>{currentQuestion.Question.question.above}</p>
//           <p>
//             <input type="radio" name="option" value="option1" />
//             {currentQuestion.Question.option1}
//           </p>
//           <p>
//             <input type="radio" name="option" value="option2" />
//             {currentQuestion.Question.option2}
//           </p>
//           <p>
//             <input type="radio" name="option" value="option3" />
//             {currentQuestion.Question.option3}
//           </p>
//           <p>
//             <input type="radio" name="option" value="option4" />
//             {currentQuestion.Question.option4}
//           </p>
//         </div>

//         <div className="question-buttons">
//           <button onClick={handleNextQuestion}>Mark for review</button>
//           <button onClick={handleNextQuestion}>Save & Next</button>
//         </div>
//       </div>
//     </div>
//   );
// };

// export default Question;
