function Finish(){

    return(
        <div>
          Exam Completed..!
        </div>
    )
}
 export default Finish;